# Zapier
Jen Krueger Submission

For this project, I downloaded Postgres and Toad Data Modeler trial versions.  

I created a theoretical data model with what I imagined might be additional fields that were somewhere in the data.  I made the model as an example of what could be modeled.  

Unfortunately, my computer wasn't hefty enough to process a bunch of SQL so I wasn't able to do an ETL process with the 9 million rows of data.  

Regardless, I went ahead and included a DDL of the model I created as well as a mockup of a data visualization that I would create using Tableau.  

